package io.rd.qltb.model;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.time.LocalDate;
import java.time.LocalDateTime;
import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
public class ApprovalGroupUserDTO {

    private Long id;

    @NotNull
    private Long userId;

    @Size(max = 255)
    private String status;

    private LocalDate timeSign;

    private LocalDateTime createdAt;

    private LocalDateTime updatedAt;

    @NotNull
    private Long group;

}
