package io.rd.qltb.service;

import io.rd.qltb.domain.Supply;
import io.rd.qltb.domain.SupplyReplacementHistory;
import io.rd.qltb.events.BeforeDeleteSupply;
import io.rd.qltb.model.SupplyReplacementHistoryDTO;
import io.rd.qltb.repos.SupplyReplacementHistoryRepository;
import io.rd.qltb.repos.SupplyRepository;
import io.rd.qltb.util.NotFoundException;
import io.rd.qltb.util.ReferencedException;
import java.util.List;
import org.springframework.context.event.EventListener;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;


@Service
public class SupplyReplacementHistoryService {

    private final SupplyReplacementHistoryRepository supplyReplacementHistoryRepository;
    private final SupplyRepository supplyRepository;

    public SupplyReplacementHistoryService(
            final SupplyReplacementHistoryRepository supplyReplacementHistoryRepository,
            final SupplyRepository supplyRepository) {
        this.supplyReplacementHistoryRepository = supplyReplacementHistoryRepository;
        this.supplyRepository = supplyRepository;
    }

    public List<SupplyReplacementHistoryDTO> findAll() {
        final List<SupplyReplacementHistory> supplyReplacementHistories = supplyReplacementHistoryRepository.findAll(Sort.by("id"));
        return supplyReplacementHistories.stream()
                .map(supplyReplacementHistory -> mapToDTO(supplyReplacementHistory, new SupplyReplacementHistoryDTO()))
                .toList();
    }

    public SupplyReplacementHistoryDTO get(final Long id) {
        return supplyReplacementHistoryRepository.findById(id)
                .map(supplyReplacementHistory -> mapToDTO(supplyReplacementHistory, new SupplyReplacementHistoryDTO()))
                .orElseThrow(NotFoundException::new);
    }

    public Long create(final SupplyReplacementHistoryDTO supplyReplacementHistoryDTO) {
        final SupplyReplacementHistory supplyReplacementHistory = new SupplyReplacementHistory();
        mapToEntity(supplyReplacementHistoryDTO, supplyReplacementHistory);
        return supplyReplacementHistoryRepository.save(supplyReplacementHistory).getId();
    }

    public void update(final Long id,
            final SupplyReplacementHistoryDTO supplyReplacementHistoryDTO) {
        final SupplyReplacementHistory supplyReplacementHistory = supplyReplacementHistoryRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        mapToEntity(supplyReplacementHistoryDTO, supplyReplacementHistory);
        supplyReplacementHistoryRepository.save(supplyReplacementHistory);
    }

    public void delete(final Long id) {
        final SupplyReplacementHistory supplyReplacementHistory = supplyReplacementHistoryRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        supplyReplacementHistoryRepository.delete(supplyReplacementHistory);
    }

    private SupplyReplacementHistoryDTO mapToDTO(
            final SupplyReplacementHistory supplyReplacementHistory,
            final SupplyReplacementHistoryDTO supplyReplacementHistoryDTO) {
        supplyReplacementHistoryDTO.setId(supplyReplacementHistory.getId());
        supplyReplacementHistoryDTO.setQuantityOld(supplyReplacementHistory.getQuantityOld());
        supplyReplacementHistoryDTO.setQuantityChange(supplyReplacementHistory.getQuantityChange());
        supplyReplacementHistoryDTO.setReason(supplyReplacementHistory.getReason());
        supplyReplacementHistoryDTO.setPlanId(supplyReplacementHistory.getPlanId());
        supplyReplacementHistoryDTO.setPlanResultId(supplyReplacementHistory.getPlanResultId());
        supplyReplacementHistoryDTO.setCreatedAt(supplyReplacementHistory.getCreatedAt());
        supplyReplacementHistoryDTO.setCreatedBy(supplyReplacementHistory.getCreatedBy());
        supplyReplacementHistoryDTO.setOldSupply(supplyReplacementHistory.getOldSupply() == null ? null : supplyReplacementHistory.getOldSupply().getId());
        supplyReplacementHistoryDTO.setNewSupply(supplyReplacementHistory.getNewSupply() == null ? null : supplyReplacementHistory.getNewSupply().getId());
        return supplyReplacementHistoryDTO;
    }

    private SupplyReplacementHistory mapToEntity(
            final SupplyReplacementHistoryDTO supplyReplacementHistoryDTO,
            final SupplyReplacementHistory supplyReplacementHistory) {
        supplyReplacementHistory.setQuantityOld(supplyReplacementHistoryDTO.getQuantityOld());
        supplyReplacementHistory.setQuantityChange(supplyReplacementHistoryDTO.getQuantityChange());
        supplyReplacementHistory.setReason(supplyReplacementHistoryDTO.getReason());
        supplyReplacementHistory.setPlanId(supplyReplacementHistoryDTO.getPlanId());
        supplyReplacementHistory.setPlanResultId(supplyReplacementHistoryDTO.getPlanResultId());
        supplyReplacementHistory.setCreatedAt(supplyReplacementHistoryDTO.getCreatedAt());
        supplyReplacementHistory.setCreatedBy(supplyReplacementHistoryDTO.getCreatedBy());
        final Supply oldSupply = supplyReplacementHistoryDTO.getOldSupply() == null ? null : supplyRepository.findById(supplyReplacementHistoryDTO.getOldSupply())
                .orElseThrow(() -> new NotFoundException("oldSupply not found"));
        supplyReplacementHistory.setOldSupply(oldSupply);
        final Supply newSupply = supplyReplacementHistoryDTO.getNewSupply() == null ? null : supplyRepository.findById(supplyReplacementHistoryDTO.getNewSupply())
                .orElseThrow(() -> new NotFoundException("newSupply not found"));
        supplyReplacementHistory.setNewSupply(newSupply);
        return supplyReplacementHistory;
    }

    @EventListener(BeforeDeleteSupply.class)
    public void on(final BeforeDeleteSupply event) {
        final ReferencedException referencedException = new ReferencedException();
        final SupplyReplacementHistory oldSupplySupplyReplacementHistory = supplyReplacementHistoryRepository.findFirstByOldSupplyId(event.getId());
        if (oldSupplySupplyReplacementHistory != null) {
            referencedException.setKey("supply.supplyReplacementHistory.oldSupply.referenced");
            referencedException.addParam(oldSupplySupplyReplacementHistory.getId());
            throw referencedException;
        }
        final SupplyReplacementHistory newSupplySupplyReplacementHistory = supplyReplacementHistoryRepository.findFirstByNewSupplyId(event.getId());
        if (newSupplySupplyReplacementHistory != null) {
            referencedException.setKey("supply.supplyReplacementHistory.newSupply.referenced");
            referencedException.addParam(newSupplySupplyReplacementHistory.getId());
            throw referencedException;
        }
    }

}
