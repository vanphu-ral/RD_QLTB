package io.rd.qltb.events;

import lombok.AllArgsConstructor;
import lombok.Getter;


@Getter
@AllArgsConstructor
public class BeforeDeleteSupply {

    private Integer id;

}
