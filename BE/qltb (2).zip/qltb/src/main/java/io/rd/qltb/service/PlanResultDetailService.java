package io.rd.qltb.service;

import io.rd.qltb.domain.PlanResult;
import io.rd.qltb.domain.PlanResultDetail;
import io.rd.qltb.events.BeforeDeletePlanResult;
import io.rd.qltb.model.PlanResultDetailDTO;
import io.rd.qltb.repos.PlanResultDetailRepository;
import io.rd.qltb.repos.PlanResultRepository;
import io.rd.qltb.util.NotFoundException;
import io.rd.qltb.util.ReferencedException;
import java.util.List;
import org.springframework.context.event.EventListener;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;


@Service
public class PlanResultDetailService {

    private final PlanResultDetailRepository planResultDetailRepository;
    private final PlanResultRepository planResultRepository;

    public PlanResultDetailService(final PlanResultDetailRepository planResultDetailRepository,
            final PlanResultRepository planResultRepository) {
        this.planResultDetailRepository = planResultDetailRepository;
        this.planResultRepository = planResultRepository;
    }

    public List<PlanResultDetailDTO> findAll() {
        final List<PlanResultDetail> planResultDetails = planResultDetailRepository.findAll(Sort.by("id"));
        return planResultDetails.stream()
                .map(planResultDetail -> mapToDTO(planResultDetail, new PlanResultDetailDTO()))
                .toList();
    }

    public PlanResultDetailDTO get(final Long id) {
        return planResultDetailRepository.findById(id)
                .map(planResultDetail -> mapToDTO(planResultDetail, new PlanResultDetailDTO()))
                .orElseThrow(NotFoundException::new);
    }

    public Long create(final PlanResultDetailDTO planResultDetailDTO) {
        final PlanResultDetail planResultDetail = new PlanResultDetail();
        mapToEntity(planResultDetailDTO, planResultDetail);
        return planResultDetailRepository.save(planResultDetail).getId();
    }

    public void update(final Long id, final PlanResultDetailDTO planResultDetailDTO) {
        final PlanResultDetail planResultDetail = planResultDetailRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        mapToEntity(planResultDetailDTO, planResultDetail);
        planResultDetailRepository.save(planResultDetail);
    }

    public void delete(final Long id) {
        final PlanResultDetail planResultDetail = planResultDetailRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        planResultDetailRepository.delete(planResultDetail);
    }

    private PlanResultDetailDTO mapToDTO(final PlanResultDetail planResultDetail,
            final PlanResultDetailDTO planResultDetailDTO) {
        planResultDetailDTO.setId(planResultDetail.getId());
        planResultDetailDTO.setCriticalCode(planResultDetail.getCriticalCode());
        planResultDetailDTO.setCriticalName(planResultDetail.getCriticalName());
        planResultDetailDTO.setFrequency(planResultDetail.getFrequency());
        planResultDetailDTO.setType(planResultDetail.getType());
        planResultDetailDTO.setResult(planResultDetail.getResult());
        planResultDetailDTO.setNote(planResultDetail.getNote());
        planResultDetailDTO.setUnit(planResultDetail.getUnit());
        planResultDetailDTO.setMin(planResultDetail.getMin());
        planResultDetailDTO.setMax(planResultDetail.getMax());
        planResultDetailDTO.setCreatedAt(planResultDetail.getCreatedAt());
        planResultDetailDTO.setUpdatedAt(planResultDetail.getUpdatedAt());
        planResultDetailDTO.setCreatedBy(planResultDetail.getCreatedBy());
        planResultDetailDTO.setUpdatedBy(planResultDetail.getUpdatedBy());
        planResultDetailDTO.setStatus(planResultDetail.getStatus());
        planResultDetailDTO.setPlanResult(planResultDetail.getPlanResult() == null ? null : planResultDetail.getPlanResult().getId());
        return planResultDetailDTO;
    }

    private PlanResultDetail mapToEntity(final PlanResultDetailDTO planResultDetailDTO,
            final PlanResultDetail planResultDetail) {
        planResultDetail.setCriticalCode(planResultDetailDTO.getCriticalCode());
        planResultDetail.setCriticalName(planResultDetailDTO.getCriticalName());
        planResultDetail.setFrequency(planResultDetailDTO.getFrequency());
        planResultDetail.setType(planResultDetailDTO.getType());
        planResultDetail.setResult(planResultDetailDTO.getResult());
        planResultDetail.setNote(planResultDetailDTO.getNote());
        planResultDetail.setUnit(planResultDetailDTO.getUnit());
        planResultDetail.setMin(planResultDetailDTO.getMin());
        planResultDetail.setMax(planResultDetailDTO.getMax());
        planResultDetail.setCreatedAt(planResultDetailDTO.getCreatedAt());
        planResultDetail.setUpdatedAt(planResultDetailDTO.getUpdatedAt());
        planResultDetail.setCreatedBy(planResultDetailDTO.getCreatedBy());
        planResultDetail.setUpdatedBy(planResultDetailDTO.getUpdatedBy());
        planResultDetail.setStatus(planResultDetailDTO.getStatus());
        final PlanResult planResult = planResultDetailDTO.getPlanResult() == null ? null : planResultRepository.findById(planResultDetailDTO.getPlanResult())
                .orElseThrow(() -> new NotFoundException("planResult not found"));
        planResultDetail.setPlanResult(planResult);
        return planResultDetail;
    }

    @EventListener(BeforeDeletePlanResult.class)
    public void on(final BeforeDeletePlanResult event) {
        final ReferencedException referencedException = new ReferencedException();
        final PlanResultDetail planResultPlanResultDetail = planResultDetailRepository.findFirstByPlanResultId(event.getId());
        if (planResultPlanResultDetail != null) {
            referencedException.setKey("planResult.planResultDetail.planResult.referenced");
            referencedException.addParam(planResultPlanResultDetail.getId());
            throw referencedException;
        }
    }

}
