package io.rd.qltb.service;

import io.rd.qltb.domain.Branch;
import io.rd.qltb.domain.Device;
import io.rd.qltb.domain.DeviceGroup;
import io.rd.qltb.domain.Line;
import io.rd.qltb.domain.Team;
import io.rd.qltb.events.BeforeDeleteBranch;
import io.rd.qltb.events.BeforeDeleteDevice;
import io.rd.qltb.events.BeforeDeleteDeviceGroup;
import io.rd.qltb.events.BeforeDeleteLine;
import io.rd.qltb.events.BeforeDeleteTeam;
import io.rd.qltb.model.DeviceDTO;
import io.rd.qltb.repos.BranchRepository;
import io.rd.qltb.repos.DeviceGroupRepository;
import io.rd.qltb.repos.DeviceRepository;
import io.rd.qltb.repos.LineRepository;
import io.rd.qltb.repos.TeamRepository;
import io.rd.qltb.util.NotFoundException;
import io.rd.qltb.util.ReferencedException;
import java.util.List;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.context.event.EventListener;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;


@Service
public class DeviceService {

    private final DeviceRepository deviceRepository;
    private final DeviceGroupRepository deviceGroupRepository;
    private final LineRepository lineRepository;
    private final BranchRepository branchRepository;
    private final TeamRepository teamRepository;
    private final ApplicationEventPublisher publisher;

    public DeviceService(final DeviceRepository deviceRepository,
            final DeviceGroupRepository deviceGroupRepository, final LineRepository lineRepository,
            final BranchRepository branchRepository, final TeamRepository teamRepository,
            final ApplicationEventPublisher publisher) {
        this.deviceRepository = deviceRepository;
        this.deviceGroupRepository = deviceGroupRepository;
        this.lineRepository = lineRepository;
        this.branchRepository = branchRepository;
        this.teamRepository = teamRepository;
        this.publisher = publisher;
    }

    public List<DeviceDTO> findAll() {
        final List<Device> devices = deviceRepository.findAll(Sort.by("id"));
        return devices.stream()
                .map(device -> mapToDTO(device, new DeviceDTO()))
                .toList();
    }

    public DeviceDTO get(final Integer id) {
        return deviceRepository.findById(id)
                .map(device -> mapToDTO(device, new DeviceDTO()))
                .orElseThrow(NotFoundException::new);
    }

    public Integer create(final DeviceDTO deviceDTO) {
        final Device device = new Device();
        mapToEntity(deviceDTO, device);
        return deviceRepository.save(device).getId();
    }

    public void update(final Integer id, final DeviceDTO deviceDTO) {
        final Device device = deviceRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        mapToEntity(deviceDTO, device);
        deviceRepository.save(device);
    }

    public void delete(final Integer id) {
        final Device device = deviceRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        publisher.publishEvent(new BeforeDeleteDevice(id));
        deviceRepository.delete(device);
    }

    private DeviceDTO mapToDTO(final Device device, final DeviceDTO deviceDTO) {
        deviceDTO.setId(device.getId());
        deviceDTO.setCode(device.getCode());
        deviceDTO.setName(device.getName());
        deviceDTO.setNumMaterialUse(device.getNumMaterialUse());
        deviceDTO.setSerialNumber(device.getSerialNumber());
        deviceDTO.setSource(device.getSource());
        deviceDTO.setInstallationDate(device.getInstallationDate());
        deviceDTO.setMaintenanceCycle(device.getMaintenanceCycle());
        deviceDTO.setDateManufacture(device.getDateManufacture());
        deviceDTO.setUnit(device.getUnit());
        deviceDTO.setPrice(device.getPrice());
        deviceDTO.setStatus(device.getStatus());
        deviceDTO.setQrcode(device.getQrcode());
        deviceDTO.setImg(device.getImg());
        deviceDTO.setUserManager(device.getUserManager());
        deviceDTO.setCreatedAt(device.getCreatedAt());
        deviceDTO.setUpdatedAt(device.getUpdatedAt());
        deviceDTO.setCreatedBy(device.getCreatedBy());
        deviceDTO.setUpdatedBy(device.getUpdatedBy());
        deviceDTO.setSupplier(device.getSupplier());
        deviceDTO.setGroup(device.getGroup() == null ? null : device.getGroup().getId());
        deviceDTO.setLine(device.getLine() == null ? null : device.getLine().getId());
        deviceDTO.setBranch(device.getBranch() == null ? null : device.getBranch().getId());
        deviceDTO.setTeam(device.getTeam() == null ? null : device.getTeam().getId());
        return deviceDTO;
    }

    private Device mapToEntity(final DeviceDTO deviceDTO, final Device device) {
        device.setCode(deviceDTO.getCode());
        device.setName(deviceDTO.getName());
        device.setNumMaterialUse(deviceDTO.getNumMaterialUse());
        device.setSerialNumber(deviceDTO.getSerialNumber());
        device.setSource(deviceDTO.getSource());
        device.setInstallationDate(deviceDTO.getInstallationDate());
        device.setMaintenanceCycle(deviceDTO.getMaintenanceCycle());
        device.setDateManufacture(deviceDTO.getDateManufacture());
        device.setUnit(deviceDTO.getUnit());
        device.setPrice(deviceDTO.getPrice());
        device.setStatus(deviceDTO.getStatus());
        device.setQrcode(deviceDTO.getQrcode());
        device.setImg(deviceDTO.getImg());
        device.setUserManager(deviceDTO.getUserManager());
        device.setCreatedAt(deviceDTO.getCreatedAt());
        device.setUpdatedAt(deviceDTO.getUpdatedAt());
        device.setCreatedBy(deviceDTO.getCreatedBy());
        device.setUpdatedBy(deviceDTO.getUpdatedBy());
        device.setSupplier(deviceDTO.getSupplier());
        final DeviceGroup group = deviceDTO.getGroup() == null ? null : deviceGroupRepository.findById(deviceDTO.getGroup())
                .orElseThrow(() -> new NotFoundException("group not found"));
        device.setGroup(group);
        final Line line = deviceDTO.getLine() == null ? null : lineRepository.findById(deviceDTO.getLine())
                .orElseThrow(() -> new NotFoundException("line not found"));
        device.setLine(line);
        final Branch branch = deviceDTO.getBranch() == null ? null : branchRepository.findById(deviceDTO.getBranch())
                .orElseThrow(() -> new NotFoundException("branch not found"));
        device.setBranch(branch);
        final Team team = deviceDTO.getTeam() == null ? null : teamRepository.findById(deviceDTO.getTeam())
                .orElseThrow(() -> new NotFoundException("team not found"));
        device.setTeam(team);
        return device;
    }

    @EventListener(BeforeDeleteDeviceGroup.class)
    public void on(final BeforeDeleteDeviceGroup event) {
        final ReferencedException referencedException = new ReferencedException();
        final Device groupDevice = deviceRepository.findFirstByGroupId(event.getId());
        if (groupDevice != null) {
            referencedException.setKey("deviceGroup.device.group.referenced");
            referencedException.addParam(groupDevice.getId());
            throw referencedException;
        }
    }

    @EventListener(BeforeDeleteLine.class)
    public void on(final BeforeDeleteLine event) {
        final ReferencedException referencedException = new ReferencedException();
        final Device lineDevice = deviceRepository.findFirstByLineId(event.getId());
        if (lineDevice != null) {
            referencedException.setKey("line.device.line.referenced");
            referencedException.addParam(lineDevice.getId());
            throw referencedException;
        }
    }

    @EventListener(BeforeDeleteBranch.class)
    public void on(final BeforeDeleteBranch event) {
        final ReferencedException referencedException = new ReferencedException();
        final Device branchDevice = deviceRepository.findFirstByBranchId(event.getId());
        if (branchDevice != null) {
            referencedException.setKey("branch.device.branch.referenced");
            referencedException.addParam(branchDevice.getId());
            throw referencedException;
        }
    }

    @EventListener(BeforeDeleteTeam.class)
    public void on(final BeforeDeleteTeam event) {
        final ReferencedException referencedException = new ReferencedException();
        final Device teamDevice = deviceRepository.findFirstByTeamId(event.getId());
        if (teamDevice != null) {
            referencedException.setKey("team.device.team.referenced");
            referencedException.addParam(teamDevice.getId());
            throw referencedException;
        }
    }

}
