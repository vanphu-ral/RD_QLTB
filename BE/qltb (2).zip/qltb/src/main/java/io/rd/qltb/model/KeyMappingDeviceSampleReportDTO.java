package io.rd.qltb.model;

import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
public class KeyMappingDeviceSampleReportDTO {

    private Integer id;

    @NotNull
    private Integer sampleReport;

    @NotNull
    private Integer deviceGroup;

}
