package io.rd.qltb.model;

import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
public class KeyMappingDTO {

    private Integer id;

    private Long criterialGroupId;

    @NotNull
    private Integer sampleReport;

    @NotNull
    private Long criterial;

}
